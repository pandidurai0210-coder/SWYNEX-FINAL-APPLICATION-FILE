"""Central configuration constants."""

MODEL_NAME = "gemini-2.5-flash"

MIN_INPUT_CHARS = 20
MAX_INPUT_CHARS = 20000
MIN_TOPIC_CHARS = 3
MAX_TOPIC_CHARS = 300

SUMMARY_STYLES = ["Paragraph", "Bullet points", "One-line TL;DR"]
SUMMARY_LENGTHS = ["Short", "Medium", "Detailed"]
CONTENT_TYPES = ["Blog post", "Email", "Social media post", "Product description", "Essay", "Story"]
TONES = ["Professional", "Casual", "Friendly", "Persuasive", "Formal"]
CONTENT_LENGTHS = ["Short", "Medium", "Long"]

SCORE_MIN = 1
SCORE_MAX = 10
