# SWYNEX – Intelligent AI Assistant

Final AI application (Task 4) for the SWYNEX Technologies AI Internship.

## Features
- AI-powered text summarization (paragraph / bullets / TL;DR)
- Intelligent content generation (blog, email, social post, etc.)
- AI response quality evaluation: relevance, completeness, clarity (1-10) + overall score
- Input validation and friendly error handling
- Interactive Streamlit UI with history and download

## Tech stack
Python | Google Gemini 2.5 Flash | Google GenAI SDK | Streamlit | JSON | unit testing (pytest)

## Run it
```bash
python -m venv venv
source venv/bin/activate          # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env              # then paste your key (https://aistudio.google.com/apikey)
streamlit run app.py
```
Open http://localhost:8501. You can also paste the API key into the sidebar.

## Test
```bash
pytest -v
```
Tests mock the Gemini API, so they run offline and need no key.

## Structure
```
app.py                  Streamlit UI
swynex/config.py        Constants
swynex/validation.py    Input validation
swynex/gemini_client.py Gemini wrapper + error mapping
swynex/features.py      Summarize / generate
swynex/evaluator.py     Quality scoring (JSON)
tests/                  Unit tests
```
