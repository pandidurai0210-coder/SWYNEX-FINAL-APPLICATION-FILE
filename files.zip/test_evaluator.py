import json

import pytest

from swynex.errors import AIServiceError, ValidationError
from swynex.evaluator import evaluate_response, parse_evaluation


def good(**over):
    d = {"relevance": 9, "completeness": 8, "clarity": 7, "feedback": "Solid."}
    d.update(over)
    return json.dumps(d)


def test_parse_plain_json():
    ev = parse_evaluation(good())
    assert (ev.relevance, ev.completeness, ev.clarity) == (9, 8, 7)
    assert ev.overall == 8.0


def test_parse_code_fenced_json():
    assert parse_evaluation("```json\n" + good() + "\n```").clarity == 7


def test_parse_json_with_extra_text():
    assert parse_evaluation("Here you go: " + good() + " Thanks").relevance == 9


def test_scores_are_clamped():
    ev = parse_evaluation(good(relevance=99, clarity=-4))
    assert ev.relevance == 10 and ev.clarity == 1


@pytest.mark.parametrize("raw", ["not json", "[]", json.dumps({"relevance": 5}),
                                 good(relevance="abc")])
def test_bad_payloads_raise(raw):
    with pytest.raises(AIServiceError):
        parse_evaluation(raw)


class FakeClient:
    def generate(self, prompt, system_instruction=None, temperature=0.7, json_output=False):
        assert json_output is True and temperature == 0.0
        return good()


def test_evaluate_response_end_to_end():
    ev = evaluate_response(FakeClient(), "Summarization", "some input text", "some answer")
    assert ev.to_dict()["overall"] == 8.0


def test_evaluate_requires_input():
    with pytest.raises(ValidationError):
        evaluate_response(FakeClient(), "x", "", "answer")
