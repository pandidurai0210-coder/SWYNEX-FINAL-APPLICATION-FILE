"""Custom exceptions so the UI can show friendly messages."""


class SwynexError(Exception):
    """Base class for all application errors."""


class ValidationError(SwynexError):
    """User input failed validation."""


class AIServiceError(SwynexError):
    """The Gemini service failed or returned unusable output."""
