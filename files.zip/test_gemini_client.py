import pytest

from swynex.errors import AIServiceError
from swynex.gemini_client import GeminiClient


class Resp:
    def __init__(self, text):
        self.text = text


class Models:
    def __init__(self, result):
        self.result = result

    def generate_content(self, **kwargs):
        if isinstance(self.result, Exception):
            raise self.result
        return self.result


class SDK:
    def __init__(self, result):
        self.models = Models(result)


def test_returns_text():
    assert GeminiClient("k" * 30, client=SDK(Resp("  hi  "))).generate("p") == "hi"


def test_empty_response_raises():
    with pytest.raises(AIServiceError):
        GeminiClient("k" * 30, client=SDK(Resp(""))).generate("p")


@pytest.mark.parametrize("err,expected", [
    ("API key not valid", "Authentication"),
    ("429 RESOURCE_EXHAUSTED quota", "Rate limit"),
    ("503 Service Unavailable", "temporarily unavailable"),
])
def test_errors_are_friendly(err, expected):
    with pytest.raises(AIServiceError, match=expected):
        GeminiClient("k" * 30, client=SDK(Exception(err))).generate("p")
