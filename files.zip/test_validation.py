import pytest

from swynex.errors import ValidationError
from swynex.validation import validate_api_key, validate_choice, validate_text, validate_topic


def test_valid_text_is_stripped():
    assert validate_text("   " + "a" * 30 + "  ") == "a" * 30


@pytest.mark.parametrize("bad", ["", "   ", None, 123, "short"])
def test_invalid_text_rejected(bad):
    with pytest.raises(ValidationError):
        validate_text(bad)


def test_too_long_text_rejected():
    with pytest.raises(ValidationError):
        validate_text("a" * 20001)


def test_topic_rules():
    assert validate_topic("IoT") == "IoT"
    with pytest.raises(ValidationError):
        validate_topic("ab")


def test_choice():
    assert validate_choice("A", ["A", "B"], "X") == "A"
    with pytest.raises(ValidationError):
        validate_choice("C", ["A", "B"], "X")


def test_api_key():
    assert validate_api_key("  " + "k" * 30 + " ") == "k" * 30
    for bad in ["", None, "short", "has space " + "k" * 30]:
        with pytest.raises(ValidationError):
            validate_api_key(bad)
