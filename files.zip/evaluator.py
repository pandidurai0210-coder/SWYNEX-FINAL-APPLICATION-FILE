"""AI response quality evaluation: relevance, completeness and clarity scoring."""
import json
import re
from dataclasses import dataclass, asdict

from .config import SCORE_MAX, SCORE_MIN
from .errors import AIServiceError
from .validation import validate_text

CRITERIA = ("relevance", "completeness", "clarity")

EVAL_SYSTEM_PROMPT = (
    "You are a strict, fair evaluator of AI responses. Score each criterion from 1 to 10 "
    "(10 = excellent). Respond with JSON only, no extra text."
)


@dataclass
class Evaluation:
    relevance: int
    completeness: int
    clarity: int
    feedback: str

    @property
    def overall(self) -> float:
        return round((self.relevance + self.completeness + self.clarity) / 3, 1)

    def to_dict(self) -> dict:
        data = asdict(self)
        data["overall"] = self.overall
        return data


def build_eval_prompt(task: str, user_input: str, response: str) -> str:
    return (
        f"Task type: {task}\n\nUSER INPUT:\n{user_input}\n\nAI RESPONSE:\n{response}\n\n"
        "Evaluate the AI response and return JSON in exactly this shape:\n"
        '{"relevance": <1-10>, "completeness": <1-10>, "clarity": <1-10>, "feedback": "<2 sentences>"}\n'
        "relevance = how well it addresses the input; completeness = covers all key points; "
        "clarity = easy to read and well organised."
    )


def _clamp(value) -> int:
    try:
        number = int(round(float(value)))
    except (TypeError, ValueError):
        raise AIServiceError("Evaluation returned a non-numeric score.")
    return max(SCORE_MIN, min(SCORE_MAX, number))


def parse_evaluation(raw: str) -> Evaluation:
    """Parse model JSON (tolerates markdown code fences) into an Evaluation."""
    cleaned = re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.MULTILINE).strip()
    try:
        data = json.loads(cleaned)
    except json.JSONDecodeError:
        match = re.search(r"\{.*\}", cleaned, re.DOTALL)
        if not match:
            raise AIServiceError("Could not read the evaluation result.")
        try:
            data = json.loads(match.group(0))
        except json.JSONDecodeError as exc:
            raise AIServiceError("Could not read the evaluation result.") from exc
    if not isinstance(data, dict):
        raise AIServiceError("Evaluation result had an unexpected format.")
    missing = [c for c in CRITERIA if c not in data]
    if missing:
        raise AIServiceError(f"Evaluation is missing: {', '.join(missing)}.")
    return Evaluation(
        relevance=_clamp(data["relevance"]),
        completeness=_clamp(data["completeness"]),
        clarity=_clamp(data["clarity"]),
        feedback=str(data.get("feedback", "")).strip() or "No feedback provided.",
    )


def evaluate_response(client, task: str, user_input: str, response: str) -> Evaluation:
    user_input = validate_text(user_input, "Original input", min_len=3, max_len=30000)
    response = validate_text(response, "AI response", min_len=3, max_len=30000)
    raw = client.generate(build_eval_prompt(task, user_input, response),
                          system_instruction=EVAL_SYSTEM_PROMPT, temperature=0.0, json_output=True)
    return parse_evaluation(raw)
