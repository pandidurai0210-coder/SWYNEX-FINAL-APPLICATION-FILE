"""Input validation helpers."""
from .config import MAX_INPUT_CHARS, MAX_TOPIC_CHARS, MIN_INPUT_CHARS, MIN_TOPIC_CHARS
from .errors import ValidationError


def validate_text(text: object, field: str = "Text",
                  min_len: int = MIN_INPUT_CHARS, max_len: int = MAX_INPUT_CHARS) -> str:
    """Return stripped text or raise ValidationError."""
    if not isinstance(text, str):
        raise ValidationError(f"{field} must be text.")
    cleaned = text.strip()
    if not cleaned:
        raise ValidationError(f"{field} cannot be empty.")
    if len(cleaned) < min_len:
        raise ValidationError(f"{field} is too short (minimum {min_len} characters).")
    if len(cleaned) > max_len:
        raise ValidationError(f"{field} is too long (maximum {max_len} characters).")
    return cleaned


def validate_topic(topic: object) -> str:
    return validate_text(topic, "Topic", MIN_TOPIC_CHARS, MAX_TOPIC_CHARS)


def validate_choice(value: object, allowed: list, field: str) -> str:
    if value not in allowed:
        raise ValidationError(f"{field} must be one of: {', '.join(allowed)}.")
    return value


def validate_api_key(key: object) -> str:
    if not isinstance(key, str) or not key.strip():
        raise ValidationError("A Gemini API key is required. Add it in the sidebar or in your .env file.")
    key = key.strip()
    if len(key) < 20 or " " in key:
        raise ValidationError("That API key doesn't look valid.")
    return key
