"""AI features: summarization and content generation."""
from .config import CONTENT_LENGTHS, CONTENT_TYPES, SUMMARY_LENGTHS, SUMMARY_STYLES, TONES
from .validation import validate_choice, validate_text, validate_topic

SYSTEM_PROMPT = (
    "You are SWYNEX, a helpful, accurate and responsible AI assistant. "
    "Do not invent facts, stay faithful to the user's input, and be clear and well organised."
)

_LENGTH_HINT = {
    "Short": "about 2-3 sentences",
    "Medium": "about one short paragraph (4-6 sentences)",
    "Detailed": "a thorough summary covering all key points",
}
_CONTENT_HINT = {"Short": "around 100 words", "Medium": "around 250 words", "Long": "around 450 words"}


def build_summary_prompt(text: str, style: str, length: str) -> str:
    if style == "Bullet points":
        fmt = "Use concise bullet points."
    elif style == "One-line TL;DR":
        fmt = "Write exactly one sentence."
    else:
        fmt = "Write in flowing paragraph form."
    size = "" if style == "One-line TL;DR" else f"Length: {_LENGTH_HINT[length]}. "
    return f"Summarize the text below. {fmt} {size}Only use information from the text.\n\nTEXT:\n{text}"


def summarize(client, text: str, style: str = "Paragraph", length: str = "Medium") -> str:
    text = validate_text(text, "Text to summarize")
    style = validate_choice(style, SUMMARY_STYLES, "Style")
    length = validate_choice(length, SUMMARY_LENGTHS, "Length")
    return client.generate(build_summary_prompt(text, style, length),
                           system_instruction=SYSTEM_PROMPT, temperature=0.3)


def build_content_prompt(topic: str, content_type: str, tone: str, length: str) -> str:
    return (f"Write a {content_type.lower()} about: {topic}\n"
            f"Tone: {tone.lower()}. Length: {_CONTENT_HINT[length]}.\n"
            "Make it engaging, well structured and factually careful.")


def generate_content(client, topic: str, content_type: str = "Blog post",
                     tone: str = "Professional", length: str = "Medium") -> str:
    topic = validate_topic(topic)
    content_type = validate_choice(content_type, CONTENT_TYPES, "Content type")
    tone = validate_choice(tone, TONES, "Tone")
    length = validate_choice(length, CONTENT_LENGTHS, "Length")
    return client.generate(build_content_prompt(topic, content_type, tone, length),
                           system_instruction=SYSTEM_PROMPT, temperature=0.8)
