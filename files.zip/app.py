"""SWYNEX - Intelligent AI Assistant (Streamlit app).

Run with:  streamlit run app.py
"""
import os

import streamlit as st

try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:  # python-dotenv is optional
    pass

from swynex.config import (CONTENT_LENGTHS, CONTENT_TYPES, MODEL_NAME, SUMMARY_LENGTHS,
                           SUMMARY_STYLES, TONES)
from swynex.errors import SwynexError
from swynex.evaluator import evaluate_response
from swynex.features import generate_content, summarize
from swynex.gemini_client import GeminiClient
from swynex.validation import validate_api_key

st.set_page_config(page_title="SWYNEX - Intelligent AI Assistant", page_icon="🧠", layout="wide")


def default_api_key() -> str:
    key = os.getenv("GEMINI_API_KEY", "")
    if not key:
        try:
            key = st.secrets.get("GEMINI_API_KEY", "")
        except Exception:
            key = ""
    return key


def get_client(api_key: str) -> GeminiClient:
    return GeminiClient(validate_api_key(api_key))


def show_evaluation(ev) -> None:
    st.markdown("#### 📊 Response quality")
    c1, c2, c3, c4 = st.columns(4)
    c1.metric("Relevance", f"{ev.relevance}/10")
    c2.metric("Completeness", f"{ev.completeness}/10")
    c3.metric("Clarity", f"{ev.clarity}/10")
    c4.metric("Overall", f"{ev.overall}/10")
    st.progress(min(ev.overall / 10, 1.0))
    st.info(ev.feedback)


def run_task(task_key: str, task_label: str, user_input: str, fn, api_key: str, auto_eval: bool) -> None:
    """Run an AI task, store output in session state, and optionally evaluate it."""
    try:
        client = get_client(api_key)
        with st.spinner("Gemini is thinking..."):
            output = fn(client)
        evaluation = None
        if auto_eval:
            with st.spinner("Evaluating response quality..."):
                try:
                    evaluation = evaluate_response(client, task_label, user_input, output)
                except SwynexError as exc:
                    st.warning(f"Evaluation skipped: {exc}")
        st.session_state[task_key] = {"output": output, "eval": evaluation}
        st.session_state.history.insert(0, {"task": task_label, "input": user_input[:120], "output": output})
    except SwynexError as exc:
        st.error(str(exc))
    except Exception as exc:  # last-resort safety net so the app never crashes
        st.error(f"Unexpected error: {exc}")


def render_result(task_key: str) -> None:
    result = st.session_state.get(task_key)
    if result:
        st.markdown("#### ✅ Result")
        st.write(result["output"])
        st.download_button("⬇️ Download as .txt", result["output"], file_name=f"{task_key}.txt",
                           key=f"dl_{task_key}")
        if result["eval"]:
            show_evaluation(result["eval"])


# ---------------------------------------------------------------- state
st.session_state.setdefault("history", [])

# ---------------------------------------------------------------- sidebar
with st.sidebar:
    st.title("🧠 SWYNEX")
    st.caption("Intelligent AI Assistant")
    api_key = st.text_input("Gemini API key", value=default_api_key(), type="password",
                            help="Get a free key from Google AI Studio. Stored only for this session.")
    auto_eval = st.toggle("Auto-evaluate responses", value=True,
                          help="Scores each answer for relevance, completeness and clarity.")
    st.caption(f"Model: `{MODEL_NAME}`")
    if st.button("🗑️ Clear history"):
        st.session_state.history = []
        for k in ("summary", "content", "evaluation"):
            st.session_state.pop(k, None)
        st.rerun()
    st.divider()
    st.markdown("**Responsible AI**: AI output can contain mistakes. Always verify important information.")

st.title("SWYNEX – Intelligent AI Assistant")
st.write("Summarize text, generate content, and evaluate the quality of AI responses.")

tab_sum, tab_gen, tab_eval, tab_hist = st.tabs(
    ["📝 Summarize", "✍️ Generate content", "🔍 Evaluate a response", "🕘 History"])

# ---------------------------------------------------------------- summarize
with tab_sum:
    text = st.text_area("Paste the text to summarize", height=220, key="sum_text")
    c1, c2 = st.columns(2)
    style = c1.selectbox("Style", SUMMARY_STYLES, key="sum_style")
    length = c2.selectbox("Length", SUMMARY_LENGTHS, index=1, key="sum_len")
    st.caption(f"{len(text)} characters")
    if st.button("Summarize", type="primary"):
        run_task("summary", "Summarization", text,
                 lambda c: summarize(c, text, style, length), api_key, auto_eval)
    render_result("summary")

# ---------------------------------------------------------------- generate
with tab_gen:
    topic = st.text_input("Topic", placeholder="e.g. Benefits of IoT in smart agriculture", key="gen_topic")
    c1, c2, c3 = st.columns(3)
    ctype = c1.selectbox("Content type", CONTENT_TYPES, key="gen_type")
    tone = c2.selectbox("Tone", TONES, key="gen_tone")
    glen = c3.selectbox("Length", CONTENT_LENGTHS, index=1, key="gen_len")
    if st.button("Generate", type="primary"):
        run_task("content", "Content generation", topic,
                 lambda c: generate_content(c, topic, ctype, tone, glen), api_key, auto_eval)
    render_result("content")

# ---------------------------------------------------------------- evaluate
with tab_eval:
    st.write("Paste any prompt and an AI-written answer to score it.")
    e_in = st.text_area("Original prompt / input", height=120, key="eval_in")
    e_out = st.text_area("AI response to evaluate", height=160, key="eval_out")
    if st.button("Evaluate", type="primary"):
        try:
            client = get_client(api_key)
            with st.spinner("Evaluating..."):
                ev = evaluate_response(client, "General", e_in, e_out)
            st.session_state["evaluation"] = ev
        except SwynexError as exc:
            st.error(str(exc))
        except Exception as exc:
            st.error(f"Unexpected error: {exc}")
    if st.session_state.get("evaluation"):
        show_evaluation(st.session_state["evaluation"])

# ---------------------------------------------------------------- history
with tab_hist:
    if not st.session_state.history:
        st.info("Nothing here yet. Run a task and it will appear in this list.")
    for i, item in enumerate(st.session_state.history[:20]):
        with st.expander(f"{item['task']} – {item['input']}"):
            st.write(item["output"])
