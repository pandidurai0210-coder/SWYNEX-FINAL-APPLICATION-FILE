"""Thin wrapper around the Google GenAI SDK."""
from typing import Optional

from .config import MODEL_NAME
from .errors import AIServiceError


class GeminiClient:
    def __init__(self, api_key: str, model: str = MODEL_NAME, client=None):
        self.model = model
        if client is not None:  # injected (used by tests)
            self._client = client
        else:
            from google import genai  # imported lazily so tests don't need the SDK
            self._client = genai.Client(api_key=api_key)

    def generate(self, prompt: str, system_instruction: Optional[str] = None,
                 temperature: float = 0.7, json_output: bool = False) -> str:
        """Send a prompt to Gemini and return the text reply."""
        try:
            from google.genai import types
            config = types.GenerateContentConfig(
                system_instruction=system_instruction,
                temperature=temperature,
                response_mime_type="application/json" if json_output else "text/plain",
            )
            response = self._client.models.generate_content(
                model=self.model, contents=prompt, config=config)
            text = (response.text or "").strip()
        except Exception as exc:  # SDK raises many different types
            raise AIServiceError(self._friendly(exc)) from exc
        if not text:
            raise AIServiceError("The model returned an empty response. Try rephrasing your input.")
        return text

    @staticmethod
    def _friendly(exc: Exception) -> str:
        msg = str(exc)
        low = msg.lower()
        if "api key" in low or "permission" in low or "401" in low or "403" in low or "api_key" in low:
            return "Authentication failed. Please check your Gemini API key."
        if "429" in low or "quota" in low or "rate" in low or "resource_exhausted" in low:
            return "Rate limit or quota reached. Please wait a moment and try again."
        if "timeout" in low or "deadline" in low or "unavailable" in low or "503" in low:
            return "The AI service is temporarily unavailable. Please try again shortly."
        if "safety" in low or "blocked" in low:
            return "The request was blocked by safety filters. Please rephrase your input."
        return f"AI request failed: {msg[:200]}"
