import pytest

from swynex.errors import ValidationError
from swynex.features import build_summary_prompt, generate_content, summarize


class FakeClient:
    def __init__(self, reply="ok reply"):
        self.reply, self.calls = reply, []

    def generate(self, prompt, system_instruction=None, temperature=0.7, json_output=False):
        self.calls.append({"prompt": prompt, "temp": temperature})
        return self.reply


LONG = "Artificial intelligence is transforming how software is built. " * 3


def test_summarize_calls_model_with_text():
    c = FakeClient("summary")
    assert summarize(c, LONG, "Bullet points", "Short") == "summary"
    assert "bullet" in c.calls[0]["prompt"].lower()
    assert LONG.strip() in c.calls[0]["prompt"]


def test_summarize_rejects_bad_input():
    with pytest.raises(ValidationError):
        summarize(FakeClient(), "tiny")
    with pytest.raises(ValidationError):
        summarize(FakeClient(), LONG, style="Haiku")


def test_tldr_prompt_is_single_sentence():
    assert "exactly one sentence" in build_summary_prompt(LONG, "One-line TL;DR", "Short")


def test_generate_content():
    c = FakeClient("post")
    assert generate_content(c, "Smart farming", "Email", "Friendly", "Short") == "post"
    assert "email" in c.calls[0]["prompt"].lower()


def test_generate_rejects_bad_input():
    with pytest.raises(ValidationError):
        generate_content(FakeClient(), "")
    with pytest.raises(ValidationError):
        generate_content(FakeClient(), "Topic here", tone="Angry")
